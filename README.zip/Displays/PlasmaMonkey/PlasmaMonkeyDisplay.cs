﻿using BTD_Mod_Helper.Api.Display;

namespace DarksTowers.Displays.PlasmaMonkey
{
    internal class PlasmaMonkeyDisplay : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkeyDisplay";
    }
    internal class PlasmaMonkey100Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey100Display";
    }
    internal class PlasmaMonkey200Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey200Display";
    }
    internal class PlasmaMonkey300Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey300Display";
    }
    internal class PlasmaMonkey400Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey400Display";
    }
    internal class PlasmaMonkey500Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey500Display";
    }
    internal class PlasmaMonkey004Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey004Display";
    }
    internal class PlasmaMonkey005Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey005Display";
    }
    internal class PlasmaMonkey030Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey030Display";
    }
    internal class PlasmaMonkey040Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey040Display";
    }
    internal class PlasmaMonkey050Display : ModDisplay2D
    {
        protected override string TextureName => "PlasmaMonkey050Display";
    }
}
