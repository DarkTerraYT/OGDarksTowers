<a href="https://github.com/DarkTerraYT/DarksTowers/releases/latest/download/DarksTowers.dll">
    <img align="left" alt="Icon" height="90" src="Icon.png">
    <img align="right" alt="Download" height="75" src="https://raw.githubusercontent.com/gurrenm3/BTD-Mod-Helper/master/BloonsTD6%20Mod%20Helper/Resources/DownloadBtn.png">
</a>

<h1 align="center">DarksTowers</h1>

Adds some custom towers to add to your stratergies. 

Join the discord to give suggestions or ways I could balance the mod.
Invite Link: https://discord.gg/xegnVEBRuE

[![Requires BTD6 Mod Helper](https://raw.githubusercontent.com/gurrenm3/BTD-Mod-Helper/master/banner.png)](https://github.com/gurrenm3/BTD-Mod-Helper#readme)
