Added Monkey of Light

The Plasma Monkey 050 Will be Re-Added in a Later Update.