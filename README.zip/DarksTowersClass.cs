using MelonLoader;
using BTD_Mod_Helper;
using DarksTowers;

[assembly: MelonInfo(typeof(DarksTowersClass), ModHelperData.Name, ModHelperData.Version, ModHelperData.Author)]
[assembly: MelonGame("Ninja Kiwi", "BloonsTD6")]

namespace DarksTowers;

public class DarksTowersClass : BloonsTD6Mod
{
    //Nothing for now!
}