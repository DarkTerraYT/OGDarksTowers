﻿using BTD_Mod_Helper.Api.Towers;
using Il2CppAssets.Scripts.Models.Towers;
using static DarksTowers.Displays.Proj.ProjectileDisplays;

namespace DarksTowers.Upgrades.LightMonkey.Bottom
{
    internal class BottomPathUpgrades : ModUpgrade<MonkeyofLight>
    {
        public override int Path => BOTTOM;

        public override int Tier => 1;

        public override int Cost => throw new System.NotImplementedException();

        public override void ApplyUpgrade(TowerModel towerModel)
        {
            throw new System.NotImplementedException();
        }
    }
}
